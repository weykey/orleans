﻿namespace Interfaces
{
    public interface IChat : Orleans.IGrainObserver
    {
        void ReceiveMessage(string message);
    }
}