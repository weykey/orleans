﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Client.Factory;

namespace Publisher
{
    class Program
    {
        private static readonly string[] LetterArgs = new[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"};

        static async Task Main(string[] args)
        {
            IClientBuilderFactory clientBuilderFactory = new ClientBuilderFactory();
            var clientBuilder = clientBuilderFactory.Create();
            using (var client = clientBuilder.Build())
            {
                await client.Connect();
                //CODE HERE

                var streampro = client.GetStreamProvider("SMSProvider");
                var stream = streampro.GetStream<string>(Guid.Empty, null);

                foreach (var letterArg in LetterArgs)
                {
                    await stream.OnNextAsync(letterArg);
                    Thread.Sleep(5000);
                }
            }
        }
    }
}
