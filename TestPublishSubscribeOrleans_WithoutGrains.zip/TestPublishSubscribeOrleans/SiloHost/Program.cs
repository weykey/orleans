﻿using System;
using System.Threading.Tasks;
using SiloHost.Host;

namespace SiloHost
{
    class Program
    {
        static async Task Main(string[] args)
        {
            ISiloHostBuilderFactory siloBuilderFactory = new SiloHostBuilderFactory();
            var siloBuilder = siloBuilderFactory.Create();

            using (var host = siloBuilder.Build())
            {
                await host.StartAsync();

                Console.WriteLine("Press any key to stop the silo.");
                Console.ReadLine();
            }
        }
    }
}
