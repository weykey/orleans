﻿using System;
using Interfaces;
using Orleans;

namespace Grains
{
    public class Chat : Grain, IChat
    {
        public void ReceiveMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
