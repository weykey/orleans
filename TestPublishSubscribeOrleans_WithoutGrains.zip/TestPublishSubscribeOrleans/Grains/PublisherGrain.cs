﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Orleans;

namespace Grains
{
    public class PublisherGrain : Grain
    {
        private static readonly string[] LetterArgs = new[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };

        public override async Task OnActivateAsync()
        {
            var streampro = GetStreamProvider("SMSProvider");
            var stream = streampro.GetStream<string>(Guid.Empty, null);

            for (int i = 0; i < 500; i++)
            {
                foreach (var letterArg in LetterArgs)
                {
                    await stream.OnNextAsync($"{i} - {letterArg}");
                    Thread.Sleep(3000);
                }
            }
        }
    }
}
