﻿using Microsoft.Extensions.Logging;
using Orleans;
using Orleans.Hosting;

namespace Client.Factory
{
    public class ClientBuilderFactory : IClientBuilderFactory
    {
        public IClientBuilder Create()
        {
            return new ClientBuilder()
                .UseLocalhostClustering()
                .ConfigureLogging(logging => logging.AddConsole())
                .AddSimpleMessageStreamProvider("SMSProvider", options => { options.FireAndForgetDelivery = true; });
        }
    }
}