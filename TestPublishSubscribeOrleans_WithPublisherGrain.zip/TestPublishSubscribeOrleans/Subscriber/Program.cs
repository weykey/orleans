﻿using System;
using System.Threading.Tasks;
using Client.Factory;
using Orleans.Streams;

namespace Subscriber
{
    class Program
    {
        static async Task Main(string[] args)
        {
            IClientBuilderFactory clientBuilderFactory = new ClientBuilderFactory();
            var clientBuilder = clientBuilderFactory.Create();
            using (var client = clientBuilder.Build())
            {
                await client.Connect();
                //CODE HERE

                var streamProvider = client.GetStreamProvider("SMSProvider");
                var stream = streamProvider.GetStream<string>(Guid.Empty, null);
                await stream.SubscribeAsync(OnNextAsync);

                Console.ReadLine();
            }
        }

        private static Task OnNextAsync(string arg1, StreamSequenceToken arg2 = null)
        {
            Console.WriteLine($"{DateTime.UtcNow} ==> '{arg1}'");

            return Task.CompletedTask;
        }
    }
}
