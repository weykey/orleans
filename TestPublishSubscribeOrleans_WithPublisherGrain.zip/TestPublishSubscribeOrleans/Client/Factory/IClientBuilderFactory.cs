﻿using Orleans;

namespace Client.Factory
{
    public interface IClientBuilderFactory
    {
        IClientBuilder Create();
    }
}