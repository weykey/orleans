﻿using Orleans.Hosting;

namespace SiloHost.Host
{
    public interface ISiloHostBuilderFactory
    {
        ISiloHostBuilder Create();
    }
}