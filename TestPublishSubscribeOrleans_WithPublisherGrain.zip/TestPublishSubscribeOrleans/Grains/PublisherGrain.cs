﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Interfaces;
using Orleans;
using Orleans.Streams;

namespace Grains
{
    public class PublisherGrain : Grain, IPublisherGrain
    {
        private IAsyncStream<string> _asyncStream;

        public override async Task OnActivateAsync()
        {
            var streamProvider = GetStreamProvider("SMSProvider");
            _asyncStream = streamProvider.GetStream<string>(Guid.Empty, null);
            await base.OnActivateAsync();
        }

        public async Task AsyncPublish(string message)
        {
            await _asyncStream.OnNextAsync(message);
                    Thread.Sleep(3000);
        }
    }
}
