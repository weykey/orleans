﻿using System.Threading.Tasks;

namespace Interfaces
{
    public interface IPublisherGrain : Orleans.IGrainWithIntegerKey
    {
        Task AsyncPublish(string message);
    }
}