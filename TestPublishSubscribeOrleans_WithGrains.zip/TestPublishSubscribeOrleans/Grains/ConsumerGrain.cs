﻿using System;
using System.Threading.Tasks;
using Orleans;
using Orleans.Streams;

namespace Grains
{
    [ImplicitStreamSubscription("toto")]
    public class ConsumerGrain : Grain, IConsumerGrain
    {
        private StreamSubscriptionHandle<string> _subscription;

        public override async Task OnActivateAsync()
        {
            IStreamProvider streamProvider = base.GetStreamProvider("SMSProvider");
            IAsyncStream<string> stream = streamProvider.GetStream<string>(this.GetPrimaryKey(), "toto");
            _subscription = await stream.SubscribeAsync(OnNextAsync);
        }

        private static Task OnNextAsync(string arg1, StreamSequenceToken arg2 = null)
        {
            Console.WriteLine($"{DateTime.UtcNow} ==> '{arg1}'");

            return Task.CompletedTask;
        }

        public override async Task OnDeactivateAsync()
        {
            await _subscription.UnsubscribeAsync();
        }
    }
}
