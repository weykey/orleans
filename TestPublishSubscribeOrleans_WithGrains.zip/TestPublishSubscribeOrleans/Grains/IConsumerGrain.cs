﻿namespace Grains
{
    public interface IConsumerGrain : Orleans.IGrainWithGuidKey
    {
    }
}