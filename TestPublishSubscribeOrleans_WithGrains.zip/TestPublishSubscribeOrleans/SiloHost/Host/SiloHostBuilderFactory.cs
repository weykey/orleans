﻿using Microsoft.Extensions.Logging;
using Orleans.Configuration;
using Orleans.Hosting;

namespace SiloHost.Host
{
    public class SiloHostBuilderFactory : ISiloHostBuilderFactory
    {
        public ISiloHostBuilder Create()
        {
            return new SiloHostBuilder()
                .UseLocalhostClustering()
                .AddSimpleMessageStreamProvider("SMSProvider", builder => builder.FireAndForgetDelivery = true)
                .AddMemoryGrainStorage("GrainStorage")
                .AddMemoryGrainStorage("PubSubStore")
                .UseInMemoryReminderService()
                .Configure<ProcessExitHandlingOptions>(options => { options.FastKillOnProcessExit = false; })
                .ConfigureLogging(logging => logging.AddConsole());
        }
    }
}