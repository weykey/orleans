﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Client.Factory;
using Interfaces;

namespace Publisher
{
    class Program
    {
        private static readonly string[] LetterArgs = new[] {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"};

        static async Task Main(string[] args)
        {
            IClientBuilderFactory clientBuilderFactory = new ClientBuilderFactory();
            var clientBuilder = clientBuilderFactory.Create();
            using (var client = clientBuilder.Build())
            {
                await client.Connect();
                //CODE HERE

                Console.WriteLine("Activate publisher");
                var publisherGrain = client.GetGrain<IPublisherGrain>(0);

                var letterArgs = new[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };

                for (var i = 0; i < 500; i++)
                {
                    foreach (var letterArg in letterArgs)
                    {
                        await publisherGrain.AsyncPublish($"{i} - {letterArg}");
                        await Task.Delay(1000);
                    }
                }
                
                Console.WriteLine("End publisher activation");
                Console.Read();
            }
        }
    }
}
